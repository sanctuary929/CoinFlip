/********************************************************************************
** Form generated from reading UI file 'startscene.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STARTSCENE_H
#define UI_STARTSCENE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_StartScene
{
public:
    QAction *actionopen;
    QAction *actiondelete;
    QWidget *centralWidget;
    QMenuBar *menuBar;

    void setupUi(QMainWindow *StartScene)
    {
        if (StartScene->objectName().isEmpty())
            StartScene->setObjectName(QString::fromUtf8("StartScene"));
        StartScene->resize(400, 300);
        actionopen = new QAction(StartScene);
        actionopen->setObjectName(QString::fromUtf8("actionopen"));
        actiondelete = new QAction(StartScene);
        actiondelete->setObjectName(QString::fromUtf8("actiondelete"));
        centralWidget = new QWidget(StartScene);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        StartScene->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(StartScene);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 400, 22));
        StartScene->setMenuBar(menuBar);

        retranslateUi(StartScene);

        QMetaObject::connectSlotsByName(StartScene);
    } // setupUi

    void retranslateUi(QMainWindow *StartScene)
    {
        StartScene->setWindowTitle(QCoreApplication::translate("StartScene", "StartScene", nullptr));
        actionopen->setText(QCoreApplication::translate("StartScene", "open", nullptr));
        actiondelete->setText(QCoreApplication::translate("StartScene", "delete", nullptr));
    } // retranslateUi

};

namespace Ui {
    class StartScene: public Ui_StartScene {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STARTSCENE_H
